print("[LEXICON] SacredText Concordance loaded.")
