# Contributing to TOTALITY ∞

1. Fork the repository
2. Clone your fork
3. Create a new branch: `git checkout -b feature/your-feature`
4. Make your changes
5. Test: `pytest`
6. Submit a Pull Request
