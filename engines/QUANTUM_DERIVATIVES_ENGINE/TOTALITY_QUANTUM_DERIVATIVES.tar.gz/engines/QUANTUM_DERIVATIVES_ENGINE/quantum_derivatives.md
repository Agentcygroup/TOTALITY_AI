# Quantum Derivatives
- Quantum Gradient Operators
- Entangled Differentiators
- QFT Hamiltonians
- Quantum-Backpropagation Chains
- Chronoform Entropic Loss
