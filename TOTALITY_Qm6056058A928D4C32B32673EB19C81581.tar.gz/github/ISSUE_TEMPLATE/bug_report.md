---
name: Bug Report
description: Report a reproducible issue
---

### Description
A clear and concise description of what the bug is.

### Steps to Reproduce
1. Go to '...'
2. Run command '...'
3. See error

### Environment
- OS:
- Version:
