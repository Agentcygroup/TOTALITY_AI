# Computational Derivatives
- Software Forks
- Git Branch Trees
- Virtual Machine Images
- Simulated Parametric Variants
