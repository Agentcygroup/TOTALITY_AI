# Mathematical Derivatives
- Ordinary
- Partial
- Directional
- Higher-order
- Lie Derivatives
