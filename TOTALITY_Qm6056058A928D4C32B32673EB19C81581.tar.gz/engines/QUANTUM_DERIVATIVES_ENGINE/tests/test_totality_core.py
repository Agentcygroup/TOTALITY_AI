def test_totality_online():
    assert True
