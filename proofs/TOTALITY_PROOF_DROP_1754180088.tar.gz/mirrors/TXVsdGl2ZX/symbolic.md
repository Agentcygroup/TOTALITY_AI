# Canonical Overlay for Multiversal App Store
# Canonical Overlay for Multiversal App Store — degree 1 extension
# Canonical Overlay for Multiversal App Store — degree 2 extension
# Canonical Overlay for Multiversal App Store — degree 3 extension
# Canonical Overlay for Multiversal App Store — degree 4 extension
# Canonical Overlay for Multiversal App Store — degree 5 extension
# Canonical Overlay for Multiversal App Store — degree 6 extension
# Canonical Overlay for Multiversal App Store — degree 7 extension
# Canonical Overlay for Multiversal App Store — degree 8 extension
# Canonical Overlay for Multiversal App Store — degree 9 extension
# Canonical Overlay for Multiversal App Store — degree 10 extension
