# Canonical Overlay for Quantum Compiler
# Canonical Overlay for Quantum Compiler — degree 1 extension
# Canonical Overlay for Quantum Compiler — degree 2 extension
# Canonical Overlay for Quantum Compiler — degree 3 extension
# Canonical Overlay for Quantum Compiler — degree 4 extension
# Canonical Overlay for Quantum Compiler — degree 5 extension
# Canonical Overlay for Quantum Compiler — degree 6 extension
# Canonical Overlay for Quantum Compiler — degree 7 extension
# Canonical Overlay for Quantum Compiler — degree 8 extension
# Canonical Overlay for Quantum Compiler — degree 9 extension
# Canonical Overlay for Quantum Compiler — degree 10 extension
