# Canonical Overlay for Gerhardt Equations
# Canonical Overlay for Gerhardt Equations — degree 1 extension
# Canonical Overlay for Gerhardt Equations — degree 2 extension
# Canonical Overlay for Gerhardt Equations — degree 3 extension
# Canonical Overlay for Gerhardt Equations — degree 4 extension
# Canonical Overlay for Gerhardt Equations — degree 5 extension
# Canonical Overlay for Gerhardt Equations — degree 6 extension
# Canonical Overlay for Gerhardt Equations — degree 7 extension
# Canonical Overlay for Gerhardt Equations — degree 8 extension
# Canonical Overlay for Gerhardt Equations — degree 9 extension
# Canonical Overlay for Gerhardt Equations — degree 10 extension
