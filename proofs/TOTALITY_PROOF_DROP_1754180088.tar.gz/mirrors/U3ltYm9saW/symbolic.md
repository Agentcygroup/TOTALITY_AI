# Canonical Overlay for Symbolic Canon Compiler
# Canonical Overlay for Symbolic Canon Compiler — degree 1 extension
# Canonical Overlay for Symbolic Canon Compiler — degree 2 extension
# Canonical Overlay for Symbolic Canon Compiler — degree 3 extension
# Canonical Overlay for Symbolic Canon Compiler — degree 4 extension
# Canonical Overlay for Symbolic Canon Compiler — degree 5 extension
# Canonical Overlay for Symbolic Canon Compiler — degree 6 extension
# Canonical Overlay for Symbolic Canon Compiler — degree 7 extension
# Canonical Overlay for Symbolic Canon Compiler — degree 8 extension
# Canonical Overlay for Symbolic Canon Compiler — degree 9 extension
# Canonical Overlay for Symbolic Canon Compiler — degree 10 extension
