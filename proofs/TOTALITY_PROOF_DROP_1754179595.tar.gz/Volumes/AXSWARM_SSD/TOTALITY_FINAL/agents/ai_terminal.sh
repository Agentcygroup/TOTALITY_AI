#!/bin/bash
echo "🧠 TOTALITY AI TERMINAL ONLINE"
exec zsh || exec bash || exec sh
