print("[QDAG] Quantum DAG Scheduler running.")
